﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace cc.CRUD.Pages
{
	public class IndexModel : PageModel
	{
		public ActionResult OnGet()
		{
			if (User.IsInRole("Admin"))
			{
				return Redirect("/Pages/Customers/Index");
			}
			else
			{
				return Redirect("/Pages/Customers/Create");
			}

		}
	}
}
