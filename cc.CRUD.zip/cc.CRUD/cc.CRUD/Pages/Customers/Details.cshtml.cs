﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using cc.CRUD.Models;

namespace cc.CRUD.Pages.Customers
{
    public class DetailsModel : PageModel
    {
        private readonly cc.CRUD.Models.ccCRUDContext _context;

        public DetailsModel(cc.CRUD.Models.ccCRUDContext context)
        {
            _context = context;
        }

		[BindProperty(SupportsGet = true)]
		public Customer Customer { get; set; }

        public async Task<IActionResult> OnGetAsync(string ID,string roleID, string isAdmin)
        {
			ViewData["isAdmin"] = isAdmin;
            if (ID == null || roleID == null)
            {
                return NotFound();
			}
			Customer = await _context.Customer.FirstOrDefaultAsync(f => f.ID == ID);

            if (Customer == null)
            {
				return LocalRedirect("~/Customers/Create/" + ID + "/" + roleID);
			}
			return Page();
        }
    }
}
