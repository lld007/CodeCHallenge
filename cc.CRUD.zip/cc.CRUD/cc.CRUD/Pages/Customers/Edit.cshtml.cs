﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using cc.CRUD.Models;

namespace cc.CRUD.Pages.Customers
{
    public class EditModel : PageModel
    {
        private readonly cc.CRUD.Models.ccCRUDContext _context;

        public EditModel(cc.CRUD.Models.ccCRUDContext context)
        {
            _context = context;
        }

		[BindProperty(SupportsGet = true)]
		public Customer Customer { get; set; }
		public async Task<IActionResult> OnGetAsync(string ID, string isAdmin)
        {
			ViewData["isAdmin"] = isAdmin;
            Customer = await _context.Customer.FirstOrDefaultAsync(m => m.ID == ID);

            if (Customer == null)
            {
                return LocalRedirect("~/Customers/Create/"+ID);
            }
			else
			{
				return Page();
			}
		}

        public async Task<IActionResult> OnPostAsync( string isAdmin)
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Attach(Customer).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CustomerExists(Customer.ID))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
			if (isAdmin == "yes")
			{
				return RedirectToPage("./Index");
			}
			else
			{
				return LocalRedirect("~/Customers/Details/" + Customer.ID+"/"+Customer.RoleID+"/no");
			}
		}

        private bool CustomerExists(string id)
        {
            return _context.Customer.Any(e => e.ID == id);
        }
    }
}
