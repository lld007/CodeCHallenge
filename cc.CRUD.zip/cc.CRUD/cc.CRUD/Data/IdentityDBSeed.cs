﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace cc.CRUD.Data
{
	public static class IdentityDBSeed
	{
		public static void SeedUsers(UserManager<IdentityUser> userManager)
		{
			//if (!userManager ==null)
			if (userManager.FindByEmailAsync("Admin@cc.com").Result == null)
			{
				IdentityUser user = new IdentityUser
				{
					UserName = "Admin@cc.com",
					Email = "Admin@cc.com"
				};

				IdentityResult result = userManager.CreateAsync(user, "Pass.123").Result;

				if (result.Succeeded)
				{
					userManager.AddToRoleAsync(user, "Admin").Wait();
				}
			}
		}
		public static void SeedIdentityRoles (RoleManager<IdentityRole> roleManager)
		{
			if(roleManager.FindByNameAsync("Admin").Result == null){
				var result = roleManager.CreateAsync(new IdentityRole { Name = "Admin", NormalizedName = "ADMIN" }).Result;
			}
			if (roleManager.FindByNameAsync("User").Result == null)
			{
				var result = roleManager.CreateAsync(new IdentityRole { Name = "User", NormalizedName = "USER" }).Result;
			}
		}
	}
}
	//	public static async void SeedUsersAndRoles(this IApplicationBuilder app)
	//	{
	//		var context = app.ApplicationServices.GetService<IdentityDbContext>();
	//		UserWithRoles[] usersWithRoles = {
	//			new UserWithRoles("Admin@cc.com", new string[] { "Admin"},"Pass.123"),//user and optional roles and password you want to seed 
 //   //            new UserWithRoles("PlainUser"),
	//			//new UserWithRoles("Jojo",new string[]{"Distributor" }) //seed roles to existing users (e.g. facebook login).
 //           };

	//		foreach (var userWithRoles in usersWithRoles)
	//		{
	//			foreach (string role in userWithRoles.Roles)
	//				if (!context.Roles.Any(r => r.Name == role))
	//				{
	//					var roleStore = new RoleStore<IdentityRole>(context);
	//					await roleStore.CreateAsync(new IdentityRole(role));
	//				}
	//			var ExistingUser = context.Users.FirstOrDefault(p => p.NormalizedUserName == userWithRoles.User.NormalizedUserName);
	//			if (ExistingUser == null) //the following syntax: !context.Users.FirstOrDefault(p => p.NormalizedUserName == userWithRoles.User.NormalizedUserName)) 
	//									  //provokes execption:(ExecuteReader requires an open and available Connection.) 
	//				await new UserStore<IdentityUser>(context).CreateAsync(userWithRoles.User);
	//			await app.AssignRoles(userWithRoles); //assign also to existing users.
	//		}

	//		await context.SaveChangesAsync();
	//	}

	//	public static async Task<IdentityResult> AssignRoles(this IApplicationBuilder app, UserWithRoles uWR)
	//	{
	//		UserManager<IdentityUser> _userManager = app.ApplicationServices.GetService<UserManager<IdentityUser>>();
	//		IdentityUser user = await _userManager.FindByNameAsync(uWR.User.NormalizedUserName);
	//		var result = await _userManager.AddToRolesAsync(user, uWR.Roles);
	//		return result;
	//	}
	//}
	//public class UserWithRoles
	//{
	//	private IdentityUser user;
	//	public IdentityUser User { get { return user; } }
	//	public string[] Roles { get; set; }
	//	public UserWithRoles(string name, string[] roles = null, string password = "secret")
	//	{
	//		if (roles != null)
	//			Roles = roles;
	//		else
	//			Roles = new string[] { };
	//		user = new IdentityUser
	//		{
	//			Email = name + "@gmail.com",
	//			NormalizedEmail = name.ToUpper() + "@GMAIL.COM",
	//			UserName = name,
	//			NormalizedUserName = name.ToUpper(),
	//			PhoneNumber = "+1312341234",
	//			EmailConfirmed = true,
	//			PhoneNumberConfirmed = true,
	//			SecurityStamp = Guid.NewGuid().ToString("D"),
	//		};
	//		user.PasswordHash = new PasswordHasher<IdentityUser>().HashPassword(user, password);
	//	}
	//}
//}