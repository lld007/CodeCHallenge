﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace cc.CRUD.Models
{
    public class ccCRUDContext : DbContext
    {
        public ccCRUDContext (DbContextOptions<ccCRUDContext> options)
            : base(options)
        {
        }

        public DbSet<cc.CRUD.Models.Customer> Customer { get; set; }
    }
}
